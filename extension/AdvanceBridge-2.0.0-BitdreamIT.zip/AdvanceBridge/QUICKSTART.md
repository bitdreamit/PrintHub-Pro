# QUICKSTART — 5 Minutes to Silent Printing

## Step 1 — Install (once per print PC)

**Windows:** double-click `install\install-windows.bat`
**Linux/macOS:** `bash install/install-linux.sh`

## Step 2 — Start the bridge

```bash
python advancebridge.py serve
```

Keep this window open (or use `install-service` to auto-start at boot).

## Step 3 — Test

```
Browser:      http://127.0.0.1:9234/health     → {"ok": true, ...}
Test page:    python advancebridge.py testprint
Test receipt: python advancebridge.py testprint thermal
```

Paper came out? The hard part is done.

## Step 4 — Point Laravel at it

In your Laravel `.env`:

```env
ADVANCEBRIDGE_URL=http://<PRINT-PC-LAN-IP>:9234
ADVANCEBRIDGE_TOKEN=BitdreamIT-2024
```

Copy the `laravel/` package files (see `laravel/README-LARAVEL.md`),
then add the print button to any view:

```blade
<a href="{{ route('invoice.print', $invoice) }}">🖨️ Print</a>
```

Click → prints. **Silently. No dialog. Every time.**

---

## Cheat sheet

| I want to... | Do this |
|---|---|
| Print an invoice | Click `route('invoice.print', $invoice)` |
| Print a thermal receipt | `route('invoice.receipt', $invoice)` |
| See what printed | `python advancebridge.py history` |
| Print a job again | `python advancebridge.py reprint <id>` |
| Check the setup | `python advancebridge.py doctor` |
| Change the token | Set `ADVANCEBRIDGE_TOKEN` on bridge **and** Laravel `.env` |
| Use another printer | Set `ADVANCEBRIDGE_PRINTER="HP LaserJet 1020"` |
| Auto-start at boot | `python advancebridge.py install-service` |

## One-line test from any server (no Laravel needed)

```bash
curl -X POST http://<PRINT-PC-IP>:9234/testprint?token=BitdreamIT-2024
```
