<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use RuntimeException;

/**
 * AdvanceBridgeService - talks to the AdvanceBridge silent print server.
 *
 *   AdvanceBridgeService::printPdf($pdfBinary, ['title' => 'Invoice-12']);
 *   AdvanceBridgeService::printReceipt("Coke 1x 2.00\nTOTAL 2.00");
 *   AdvanceBridgeService::health();
 *
 * The bridge prints SILENTLY on the printer PC - no dialog, no confirmation.
 */
class AdvanceBridgeService
{
    /** Print a PDF (binary string) silently. Returns bridge JSON. */
    public static function printPdf(string $pdfBinary, array $opt = []): array
    {
        return self::call('/print', [
            'token'      => config('advancebridge.token'),
            'pdf_base64' => base64_encode($pdfBinary),
            'title'      => $opt['title']   ?? 'document',
            'kind'       => $opt['kind']    ?? 'a4',      // a4
            'copies'     => $opt['copies']  ?? 1,
        ] + (empty($opt['printer']) ? [] : ['printer' => $opt['printer']]));
    }

    /** Print a thermal 80mm receipt from plain text. 80 cols max. */
    public static function printReceipt(string $text, array $opt = []): array
    {
        return self::call('/print', [
            'token'   => config('advancebridge.token'),
            'text'    => $text,
            'title'   => $opt['title'] ?? 'receipt',
            'copies'  => $opt['copies'] ?? 1,
        ] + (empty($opt['printer']) ? [] : ['printer' => $opt['printer']]));
    }

    /** Ask the bridge for a list of installed printers. */
    public static function printers(): array
    {
        $res = Http::timeout(8)
            ->withToken(config('advancebridge.token'), 'X-AdvanceBridge-Token')
            ->get(rtrim(config('advancebridge.url'), '/') . '/printers');
        return $res->json('printers') ?? [];
    }

    /** True when the bridge is alive and reachable. */
    public static function health(): bool
    {
        try {
            return Http::timeout(3)
                ->get(rtrim(config('advancebridge.url'), '/') . '/health')
                ->json('ok') === true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function call(string $path, array $payload): array
    {
        $res = Http::timeout(config('advancebridge.timeout'))
            ->withHeaders(['X-AdvanceBridge-Token' => config('advancebridge.token')])
            ->post(rtrim(config('advancebridge.url'), '/') . $path, $payload);

        if ($res->failed()) {
            throw new RuntimeException('AdvanceBridge: HTTP ' . $res->status()
                . ' ' . mb_substr($res->body(), 0, 300));
        }
        return $res->json() ?? [];
    }
}
