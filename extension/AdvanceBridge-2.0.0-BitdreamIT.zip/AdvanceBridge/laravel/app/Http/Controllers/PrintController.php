<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Services\AdvanceBridgeService;
use Illuminate\Http\Request;
use Mpdf\Mpdf;
use RuntimeException;
use Throwable;

/**
 * PrintController - URL link -> silent printing, no dialogs, ever.
 *
 *   GET /invoice/{invoice}/pdf    -> raw mPDF stream  (signed URL)
 *   GET /print/invoice/{invoice}  -> prints the invoice SILENTLY
 *
 * Adapt the model import + the blade view to your project.
 */
class PrintController extends Controller
{
    /**
     * The invoice PDF stream (mPDF), protected by a signed URL.
     * Used by both direct mode and the browser auto-print page.
     */
    public function pdf(Request $request, Invoice $invoice)
    {
        $m = $this->mpdf();
        $m->WriteHTML(
            view('invoices.pdf', ['invoice' => $invoice])->render()
        );

        return response(
            $m->Output('', \Mpdf\Output\Destination::STRING_RETURN)
        )->header('Content-Type', 'application/pdf');
    }

    /**
     * THE print link:  <a href="{{ route('invoice.print', $invoice) }}">Print</a>
     *
     * mode=direct  : Laravel server -> bridge -> printer. The browser just
     *                receives a small "Sent to printer" page. No JS needed.
     * mode=browser : render an auto-print page; the visitor's browser pushes
     *                the PDF to the bridge on the visitor's PC (same PC flow).
     * mode=auto    : try direct; if the bridge is unreachable from the server
     *                (e.g. bridge sits on the cashier's PC), use the browser.
     */
    public function printInvoice(Request $request, Invoice $invoice)
    {
        $mode = config('advancebridge.mode', 'auto');

        if (in_array($mode, ['direct', 'auto'], true)) {
            try {
                $m = $this->mpdf();
                $m->WriteHTML(
                    view('invoices.pdf', ['invoice' => $invoice])->render()
                );
                $pdf = $m->Output('', \Mpdf\Output\Destination::STRING_RETURN);

                AdvanceBridgeService::printPdf($pdf, [
                    'title' => 'Invoice-' . $invoice->id,
                ]);

                return view('print.result', [
                    'ok'      => true,
                    'invoice' => $invoice,
                    'message' => 'Invoice sent to the printer (silent).',
                ]);
            } catch (Throwable $e) {
                if ($mode === 'direct') {
                    return view('print.result', [
                        'ok'      => false,
                        'invoice' => $invoice,
                        'message' => 'Print failed: ' . $e->getMessage(),
                    ]);
                }
                // auto mode -> fall through to the browser page below
            }
        }

        // Browser mode: build a short-lived signed PDF URL for the visitor.
        $pdfUrl = URL::temporarySignedRoute(
            'invoice.pdf', now()->addMinutes(10), ['invoice' => $invoice->id]
        );

        return view('print.auto', [
            'invoice'  => $invoice,
            'pdfUrl'   => $pdfUrl,
            'token'    => config('advancebridge.token'),
            'bridge'   => rtrim(config('advancebridge.browser_url'), '/'),
            'title'    => 'Invoice-' . $invoice->id,
        ]);
    }

    /** Thermal receipt example:  GET /print/receipt/{invoice} */
    public function printReceipt(Request $request, Invoice $invoice)
    {
        $lines = [
            '#big ' . config('app.name'),
            '|center|RECEIPT ' . ($invoice->invoice_no ?? $invoice->id),
            '--------------------------------',
        ];
        foreach ($invoice->items ?? [] as $it) {
            $lines[] = sprintf('%-24s %8.2f', $it['name'] ?? 'Item', $it['price'] ?? 0);
        }
        $lines[] = '--------------------------------';
        $lines[] = sprintf('TOTAL %25.2f', $invoice->total ?? 0);
        $lines[] = '';
        $lines[] = '|center|Thank you!';

        try {
            AdvanceBridgeService::printReceipt(implode("\n", $lines), [
                'title' => 'Receipt-' . $invoice->id,
            ]);
            return back()->with('print_ok', 'Receipt printing...');
        } catch (RuntimeException $e) {
            return back()->with('print_err', $e->getMessage());
        }
    }

    private function mpdf(): Mpdf
    {
        return new Mpdf([
            'mode'             => 'utf-8',
            'format'           => 'A4',
            'margin_top'       => 12,
            'margin_bottom'    => 12,
            'tempDir'          => storage_path('app/mpdf'),
        ]);
    }
}
