<?php

/*
|--------------------------------------------------------------------------
| AdvanceBridge configuration  -  by Bitdream IT
|--------------------------------------------------------------------------
| Copy this file to config/advancebridge.php, then run:
|   php artisan config:clear
*/

return [

    // Bridge URL (the PC that has the printer attached)
    'url' => env('ADVANCEBRIDGE_URL', 'http://127.0.0.1:9234'),

    // Shared secret - must match the bridge token exactly
    'token' => env('ADVANCEBRIDGE_TOKEN', 'BitdreamIT-2024'),

    // Optional fixed printer name ('' = OS default printer)
    'printer' => env('ADVANCEBRIDGE_PRINTER', ''),

    // Server-side HTTP timeout (seconds)
    'timeout' => (int) env('ADVANCEBRIDGE_TIMEOUT', 10),

    // Where the VISITOR's browser should send print jobs.
    // 127.0.0.1 = the same PC the user is clicking from (most common).
    'browser_url' => env('ADVANCEBRIDGE_BROWSER_URL', 'http://127.0.0.1:9234'),

    // direct | browser | auto
    'mode' => env('ADVANCEBRIDGE_MODE', 'auto'),

];
