# AdvanceBridge — Laravel Integration (Full Package)

One-click **silent printing** from your Laravel app. Click a URL in Chrome,
Edge, Firefox or on your phone — the invoice prints on the office printer.
**No print dialog. No confirmation. Nothing to click.**

```
Browser click  ->  Laravel (mPDF stream)  ->  AdvanceBridge (Python, tiny)
                                              -> OS default printer  [SILENT]
```

---

## 1. Install (2 minutes)

```bash
# in your Laravel project
composer require mpdf/mpdf

# copy the files from this package into your app:
#   config/advancebridge.php                -> config/advancebridge.php
#   app/Services/AdvanceBridgeService.php   -> app/Services/
#   app/Http/Controllers/PrintController.php-> app/Http/Controllers/
#   routes/web-additions.php                -> paste into routes/web.php
#   resources/views/print/*                 -> resources/views/print/
#   resources/views/invoices/pdf.blade.php  -> resources/views/invoices/
#   .env.additions                          -> merge into your .env

php artisan config:clear
mkdir -p storage/app/mpdf && chmod -R 775 storage
```

## 2. Set the .env values

```env
ADVANCEBRIDGE_URL=http://192.168.0.50:9234   # LAN IP of the print PC
ADVANCEBRIDGE_TOKEN=BitdreamIT-2024          # same as bridge token
ADVANCEBRIDGE_MODE=auto                      # direct | browser | auto
```

Find the print PC's LAN IP with `ipconfig` (Windows) or `hostname -I` (Linux).
The bridge must be running there: `python advancebridge.py serve`.

## 3. Print modes — pick what fits your shop

| Mode | Flow | Best when |
|------|------|-----------|
| `direct` | Laravel server sends the PDF to the bridge. Browser gets a small result page. **No JavaScript at all.** | Printer hangs off the network / server PC |
| `browser` | Click opens a tiny auto-print page; the **visitor's browser** pushes the PDF to the bridge on the **visitor's own PC** (`127.0.0.1`). | Cashier PC has its own printer |
| `auto` (default) | Try direct; if the bridge is unreachable from the server, use the browser page. | You want it to just work everywhere |

## 4. Use it in your views

```blade
{{-- one-click silent print --}}
<a href="{{ route('invoice.print', $invoice) }}">🖨️ Print invoice</a>

{{-- thermal receipt (80mm) --}}
<a href="{{ route('invoice.receipt', $invoice) }}">Receipt</a>

{{-- just the PDF (download / preview) --}}
<a href="{{ URL::temporarySignedRoute('invoice.pdf', now()->addMinutes(10), ['invoice' => $invoice->id]) }}">PDF</a>
```

Printing feedback via flash session (direct/receipt mode):

```blade
@if(session('print_ok'))  <div class="alert success">{{ session('print_ok') }}</div> @endif
@if(session('print_err')) <div class="alert error">{{ session('print_err') }}</div> @endif
```

## 5. Print from PHP anywhere (queues, jobs, APIs)

```php
use App\Services\AdvanceBridgeService;

$pdf = view('invoices.pdf', ['invoice' => $invoice])->render();
AdvanceBridgeService::printPdf($pdf, ['title' => 'Invoice-' . $invoice->id]);

// thermal receipt straight from text
AdvanceBridgeService::printReceipt("Shop Name\nCoke 1x 2.00\nTOTAL 2.00\n");

// housekeeping
$alive    = AdvanceBridgeService::health();
$printers = AdvanceBridgeService::printers();
```

## 6. Signed URL security

`/invoice/{id}/pdf` is wrapped in `signed` middleware — the URL contains an
HMAC signature + expiry, so nobody can fetch other customers' invoices by
guessing IDs. The auto-print page generates a fresh signed URL valid for
**10 minutes** on every click.

## 7. Troubleshooting

| Symptom | Fix |
|---------|-----|
| "Bridge not reachable" | Bridge not running on the print PC — `python advancebridge.py serve` |
| HTTP 401 in Laravel log | Token mismatch between `.env` and bridge `ADVANCEBRIDGE_TOKEN` |
| Prints but on wrong printer | Set `ADVANCEBRIDGE_PRINTER=` to the exact printer name (`python advancebridge.py printers`) |
| Browser mode blocked (rare, corporate policy) | The page automatically falls back to a hidden-form POST; if even that fails, switch `ADVANCEBRIDGE_MODE=direct` |
| Nothing prints, no error | Run `python advancebridge.py doctor` on the print PC; check `python advancebridge.py history` |
| Bangla text broken in PDF | mPDF needs a Bengali font: add `'fontdata' => ['nikosh' => ['R' => 'Nikosh.ttf']]` and set `font-family` in the blade view |
