<?php

/*
|--------------------------------------------------------------------------
| AdvanceBridge routes - paste into your routes/web.php
|--------------------------------------------------------------------------
| Remember to add at the top of web.php:
|   use App\Http\Controllers\PrintController;
*/

// Raw PDF stream - protected with a signed URL (cannot be guessed or shared).
Route::middleware(['auth', 'signed'])
    ->get('/invoice/{invoice}/pdf', [PrintController::class, 'pdf'])
    ->name('invoice.pdf');

// THE one-click silent print link (A4 invoice)
Route::middleware('auth')
    ->get('/print/invoice/{invoice}', [PrintController::class, 'printInvoice'])
    ->name('invoice.print');

// Thermal 80mm receipt (optional)
Route::middleware('auth')
    ->get('/print/receipt/{invoice}', [PrintController::class, 'printReceipt'])
    ->name('invoice.receipt');
