<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{{ $ok ? 'Printed' : 'Print failed' }} - {{ $title ?? 'AdvanceBridge' }}</title>
<style>
  body  { font-family:-apple-system,Segoe UI,Roboto,sans-serif; background:#0f172a;
          color:#e2e8f0; text-align:center; padding-top:12vh; }
  .card { max-width:480px; margin:0 auto; background:#1e293b; border-radius:14px;
          padding:34px 28px; }
  .ico  { font-size:46px; }
  .ok   { color:#34d399; } .err { color:#f87171; }
  p     { color:#94a3b8; font-size:14px; }
  a,button { display:inline-block; margin-top:14px; background:#2563eb; color:#fff;
          border:0; border-radius:8px; padding:10px 22px; text-decoration:none;
          font-size:15px; cursor:pointer; }
  .ghost{ background:#334155; }
</style>
</head>
<body>
<div class="card">
    <div class="ico">{{ $ok ? '&#9989;' : '&#10060;' }}</div>
    <h2 class="{{ $ok ? 'ok' : 'err' }}">{{ $ok ? 'Sent to printer' : 'Print failed' }}</h2>
    <p>{{ $message }}</p>
    @if($ok)
        <p>The document printed silently &mdash; no dialog was shown.</p>
    @else
        <p>Check that AdvanceBridge is running on the print PC:<br>
           <code>python advancebridge.py serve</code></p>
    @endif
    <a class="ghost" href="javascript:history.back()">Back</a>
</div>
<script>
    // auto-close when opened as a small print window
    setTimeout(function () { if (window.opener) window.close(); }, 2500);
</script>
</body>
</html>
