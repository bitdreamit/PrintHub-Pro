<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Printing {{ $title }} ...</title>
<style>
  body  { font-family: -apple-system, Segoe UI, Roboto, sans-serif;
          background:#0f172a; color:#e2e8f0; text-align:center; padding-top:9vh; }
  .card { max-width:520px; margin:0 auto; background:#1e293b; border-radius:14px;
          padding:34px 28px; box-shadow:0 10px 40px rgba(0,0,0,.45); }
  .ico  { font-size:44px; line-height:1; }
  h2    { margin:14px 0 6px; font-size:22px; }
  .sub  { color:#94a3b8; font-size:14px; margin-bottom:18px; }
  #st   { font-size:16px; font-weight:600; padding:10px 0; }
  .ok   { color:#34d399; } .err { color:#f87171; } .wait { color:#fbbf24; }
  button{ background:#2563eb; color:#fff; border:0; border-radius:8px;
          padding:10px 22px; font-size:15px; cursor:pointer; margin:4px; }
  button.ghost { background:#334155; }
  iframe{ display:none; }
</style>
</head>
<body>
<div class="card">
  <div class="ico">&#128424;&#65039;</div>
  <h2>{{ $title }}</h2>
  <div class="sub">AdvanceBridge silent printing &mdash; no dialog will appear</div>

  <div id="st" class="wait">Sending to the printer...</div>

  <div style="margin-top:16px">
    <button id="again" class="ghost" onclick="location.reload()">Try again</button>
    <button id="close" class="ghost" style="display:none"
            onclick="window.close()">Close</button>
  </div>
</div>

{{-- Browser -> bridge (127.0.0.1). PHP is only used to build these values. --}}
<script>
    var BRIDGE = @json($bridge);      // http://127.0.0.1:9234
    var TOKEN  = @json($token);
    var PDFURL = @json($pdfUrl);      // signed Laravel PDF stream
    var TITLE  = @json($title);
</script>

<iframe name="bridgeFrame" id="bridgeFrame"></iframe>

<script>
function toB64(buf) {                     // chunked - safe for big PDFs
    var bytes = new Uint8Array(buf), bin = "", CH = 0x8000;
    for (var i = 0; i < bytes.length; i += CH)
        bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return btoa(bin);
}
function formFallback(json) {             // no-CORS-preflight hidden form POST
    var f = document.createElement("form");
    f.method = "POST"; f.action = BRIDGE + "/print";
    f.target = "bridgeFrame"; f.enctype = "application/x-www-form-urlencoded";
    var i = document.createElement("input");
    i.type = "hidden"; i.name = "payload"; i.value = JSON.stringify(json);
    f.appendChild(i); document.body.appendChild(f); f.submit();
}
function setStatus(cls, txt, done) {
    var s = document.getElementById("st");
    s.className = cls; s.textContent = txt;
    document.getElementById("close").style.display = done ? "" : "none";
}
async function go() {
    try {
        setStatus("wait", "Fetching document...");
        var r = await fetch(PDFURL, { credentials: "include" });
        if (!r.ok) throw new Error("Laravel PDF URL returned " + r.status);
        var b64 = toB64(await r.arrayBuffer());

        setStatus("wait", "Sending to printer...");
        var res = await fetch(BRIDGE + "/print", {
            method: "POST",
            headers: { "Content-Type": "application/json",
                       "X-AdvanceBridge-Token": TOKEN },
            body: JSON.stringify({ pdf_base64: b64, title: TITLE, kind: "a4" })
        });
        var j = await res.json();
        if (j.ok) setStatus("ok", "PRINTED - check your printer", true);
        else      { setStatus("err", "Bridge says: " + (j.error || j), false);
                    formFallback({ pdf_base64: b64, title: TITLE, kind: "a4", token: TOKEN }); }
    } catch (e) {
        // fetch blocked (strict browser / PNA) -> one-shot form fallback
        try {
            var r2 = await fetch(PDFURL, { credentials: "include" });
            if (!r2.ok) throw new Error("PDF URL " + r2.status);
            var b642 = toB64(await r2.arrayBuffer());
            formFallback({ pdf_base64: b642, title: TITLE, kind: "a4", token: TOKEN });
            setStatus("ok", "Sent to printer (compatibility mode).", true);
        } catch (e2) {
            setStatus("err", "Bridge not reachable on this PC (" + e2.message +
                      "). Is AdvanceBridge running?", false);
        }
    }
}
go();
</script>
</body>
</html>
