{{-- ============================================================
  Sample mPDF invoice template - resources/views/invoices/pdf.blade.php
  Adapt the fields to your Invoice model. mPDF supports most
  inline CSS - keep it simple and table-based.
============================================================ --}}
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    body   { font-family: sans-serif; font-size: 12px; color: #1f2937; }
    .wrap  { width: 100%; }
    .head  { width: 100%; margin-bottom: 18px; }
    .brand { font-size: 22px; font-weight: bold; color: #0f172a; }
    .muted { color: #6b7280; font-size: 11px; }
    .invno { font-size: 16px; font-weight: bold; text-align: right; }
    table.items { width: 100%; border-collapse: collapse; margin-top: 14px; }
    table.items th {
        background: #0f172a; color: #ffffff; padding: 7px 8px;
        font-size: 11px; text-align: left;
    }
    table.items td { border-bottom: 1px solid #e5e7eb; padding: 6px 8px; }
    .r { text-align: right; }
    .totals { width: 45%; margin-left: 55%; margin-top: 12px; }
    .totals td { padding: 4px 6px; }
    .grand { background: #f3f4f6; font-weight: bold; font-size: 14px; }
    .foot  { margin-top: 30px; color: #6b7280; font-size: 10px; text-align: center; }
</style>
</head>
<body>

<div class="wrap">

    <table class="head">
        <tr>
            <td>
                <div class="brand">{{ config('app.name') }}</div>
                <div class="muted">
                    {{ $invoice->company_address ?? 'Your Company, Dhaka, Bangladesh' }}<br>
                    {{ $invoice->company_phone ?? '+880 1XXX-XXXXXX' }}
                </div>
            </td>
            <td class="r">
                <div class="invno">INVOICE #{{ $invoice->invoice_no ?? $invoice->id }}</div>
                <div class="muted">
                    Date: {{ $invoice->created_at?->format('d M Y') ?? date('d M Y') }}<br>
                    Status: {{ strtoupper($invoice->status ?? 'paid') }}
                </div>
            </td>
        </tr>
    </table>

    <table>
        <tr>
            <td>
                <b>Billed to:</b><br>
                {{ $invoice->customer_name ?? 'Customer' }}<br>
                <span class="muted">{{ $invoice->customer_address ?? '' }}</span>
            </td>
        </tr>
    </table>

    <table class="items">
        <thead>
        <tr>
            <th width="5%">#</th>
            <th width="45%">Item</th>
            <th width="15%" class="r">Qty</th>
            <th width="15%" class="r">Price</th>
            <th width="20%" class="r">Amount</th>
        </tr>
        </thead>
        <tbody>
        @foreach(($invoice->items ?? []) as $i => $it)
            <tr>
                <td>{{ $i + 1 }}</td>
                <td>{{ $it['name'] ?? 'Item' }}</td>
                <td class="r">{{ $it['qty'] ?? 1 }}</td>
                <td class="r">{{ number_format($it['price'] ?? 0, 2) }}</td>
                <td class="r">{{ number_format(($it['qty'] ?? 1) * ($it['price'] ?? 0), 2) }}</td>
            </tr>
        @endforeach
        @if(empty($invoice->items))
            <tr>
                <td>1</td><td>Sample service</td>
                <td class="r">1</td><td class="r">100.00</td><td class="r">100.00</td>
            </tr>
        @endif
        </tbody>
    </table>

    <table class="totals">
        <tr>
            <td>Subtotal</td>
            <td class="r">{{ number_format($invoice->subtotal ?? ($invoice->total ?? 0), 2) }}</td>
        </tr>
        <tr>
            <td>VAT / Tax ({{ $invoice->vat_rate ?? 0 }}%)</td>
            <td class="r">{{ number_format($invoice->vat ?? 0, 2) }}</td>
        </tr>
        <tr class="grand">
            <td>TOTAL (BDT)</td>
            <td class="r">{{ number_format($invoice->total ?? 0, 2) }}</td>
        </tr>
    </table>

    <div class="foot">
        Thank you for your business!<br>
        Printed via AdvanceBridge by Bitdream IT
    </div>

</div>

</body>
</html>
