# AdvanceBridge HTTP API v2.0.0

Base URL: `http://<PRINT-PC-IP>:9234`
Auth: send the token as header `X-AdvanceBridge-Token: <token>` (preferred),
as JSON field `"token"`, or as query `?token=`. Tokens are compared in
constant time. All responses are JSON unless noted.

---

## Endpoints

| Method | Path | Auth | Purpose |
|--------|------|------|---------|
| GET  | `/health` | — | Availability probe (public by design) |
| GET  | `/printers` | ✓ | List installed printers + OS default |
| GET  | `/testprint?kind=a4\|thermal` | ✓ | Queue a built-in test page |
| POST | `/print` | ✓ | **Print a document** (the main endpoint) |
| GET  | `/jobs?limit=50` | ✓ | Print history (newest first) |
| GET  | `/jobs/{id}/file` | ✓ | Download the stored PDF of a job |
| POST | `/jobs/{id}/reprint` | ✓ | Queue job again (no body needed) |

## GET /health

```json
{
  "ok": true, "app": "AdvanceBridge", "version": "2.0.0",
  "os": "windows",
  "default_printer": "HP LaserJet 1020",
  "sumatra_found": true,
  "queue": 0, "token_set": true
}
```

## POST /print

Body (JSON). One of `pdf_base64`, `pdf_url`, `text` is required.

| Field | Type | Notes |
|-------|------|-------|
| `pdf_base64` | string | Base64 of a PDF (what Laravel sends) → kind `a4` |
| `pdf_url` | string | Bridge downloads the PDF itself (max 25 MB) → kind `a4` |
| `text` | string | Receipt text → auto-built 80mm PDF, kind `thermal` |
| `kind` | `a4` \| `thermal` | Optional override / explicit |
| `title` | string | Job label in history (default `document`) |
| `printer` | string | Optional printer name (default: OS default) |
| `copies` | int | 1–50 (default 1) |
| `token` | string | Alternative to the header |

Text markers for thermal: `#big ` prefix = large bold line,
`|center|` prefix = centered line.

**Request**

```bash
curl -X POST http://192.168.0.50:9234/print \
  -H "Content-Type: application/json" \
  -H "X-AdvanceBridge-Token: BitdreamIT-2024" \
  -d '{"pdf_base64":"JVBERi0xLjcK...","title":"Invoice-42","copies":1}'
```

**Response** — `200 OK`

```json
{ "ok": true, "job_id": 17, "kind": "a4", "copies": 1,
  "message": "queued to printer" }
```

**Thermal receipt**

```bash
curl -X POST http://192.168.0.50:9234/print \
  -H "Content-Type: application/json" \
  -H "X-AdvanceBridge-Token: BitdreamIT-2024" \
  -d '{"text":"#big MY SHOP\n|center|RECEIPT 1042\nCoke  1x  2.00\nTOTAL  2.00","title":"POS-1042"}'
```

**Errors**

| Code | Meaning |
|------|---------|
| 400 | Bad body / not a PDF / pdf_url failed |
| 401 | Invalid or missing token |
| 410 | Reprint target file no longer stored |
| 500 | (in history) `status: failed` with `error` message |

## GET /jobs

```json
{ "ok": true, "jobs": [
  { "id": 17, "created_at": "2026-10-09T11:20:44", "kind": "a4",
    "title": "Invoice-42", "printer": "HP LaserJet 1020", "copies": 1,
    "status": "printed", "error": null, "file_path": "...",
    "origin_ip": "192.168.0.10", "duration_ms": 812 } ] }
```

Statuses: `queued → printing → printed | failed`.

## Browser notes (CORS)

The bridge always answers with:

```
Access-Control-Allow-Origin: *
Access-Control-Allow-Private-Network: true
```

so `fetch()` from any website — including HTTPS pages calling the local
`http://127.0.0.1:9234` — is accepted by Chrome/Edge/Firefox. If a browser
still blocks the preflight, the Laravel auto-print view automatically falls
back to a hidden form POST (`application/x-www-form-urlencoded`, field
`payload` containing the JSON), which the bridge also accepts.
