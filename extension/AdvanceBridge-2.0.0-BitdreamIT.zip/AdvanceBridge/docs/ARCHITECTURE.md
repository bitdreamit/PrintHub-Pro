# AdvanceBridge — Architecture

## Why a bridge at all?

Browsers **cannot** print silently — Chrome/Firefox/Edge always show the
print preview dialog. That's a browser security rule; no website can skip it.
AdvanceBridge moves the final step out of the browser into a tiny local
server on the print PC, so printing becomes a plain HTTP call = no dialog,
ever, in every browser and OS.

## The two flows

### Flow A — DIRECT (Laravel server → bridge → printer)

```
┌────────┐  1. click /print/invoice/42   ┌──────────────┐
│ Browser│ ────────────────────────────▶ │   Laravel    │
└────────┘                               │  (mPDF)      │
                                         └──────┬───────┘
                            2. POST /print      │
                            {pdf_base64, token} │
                                                ▼
                                        ┌──────────────┐
                                        │ AdvanceBridge│ 3. serial queue
                                        │ (print PC)   │ ──▶ SumatraPDF / lp
                                        └──────┬───────┘        SILENT
                                               ▼
                                        ┌──────────────┐
                                        │   Printer    │ ◀── paper out
                                        └──────────────┘
4. Browser receives a small "Sent to printer" page. No JS, no dialogs.
```

### Flow B — BROWSER (visitor's browser → bridge on visitor's PC)

```
┌────────┐ 1. click  ┌──────────────┐  2. fetch signed PDF (10-min HMAC URL)
│ Browser│ ────────▶ │   Laravel    │ ─────────────────────────────┐
└───┬────┘           └──────────────┘                              │
    │ 3. POST http://127.0.0.1:9234/print  ◀───────────────────────┘
    │    {pdf_base64, token}         (CORS + Private-Network OK)
    ▼
┌───────────────┐   4. SumatraPDF / lp → local printer, SILENT
│ AdvanceBridge │
│ (same PC)     │
└───────────────┘
```

`mode` in `config/advancebridge.php` picks A, B, or `auto` (A first, then B).

## Components

| Piece | Tech | Job |
|---|---|---|
| `advancebridge.py` | Python stdlib only | HTTP server + queue + SQLite history + PDF engines |
| SumatraPDF (Win) | 3rd-party exe | Renders PDF → printer driver **silently** (`-silent -print-to-default`) |
| `lp` (Linux/mac) | CUPS | Same job via CUPS |
| Thermal engine | pure-Python PDF writer | Turns receipt text into an exact 80mm-wide PDF |
| `AdvanceBridgeService` (PHP) | Laravel HTTP client | Signs, wraps and POSTs documents to the bridge |
| `auto.blade.php` | Browser JS | Flow B page: fetch PDF → POST bridge (+ form fallback) |

## guarantees

- **Serial queue** — jobs are handled one-by-one; parallel clicks can't interleave pages.
- **Token** — `X-AdvanceBridge-Token` header, constant-time compare, 401 on mismatch.
- **CORS** — `*` origin + `Access-Control-Allow-Private-Network: true` → works from HTTPS sites and modern Chrome.
- **Reprint** — every job file kept in `~/.advancebridge/jobs/`, re-printable by id.
- **Audit** — SQLite `history.db`: who (origin_ip), what (title/kind), result (status/ms/error).
