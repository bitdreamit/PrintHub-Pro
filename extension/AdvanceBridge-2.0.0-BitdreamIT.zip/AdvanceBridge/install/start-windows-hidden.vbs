' ============================================================
'  AdvanceBridge - Start HIDDEN (no black window) - Bitdream IT
'  Usage: double-click, or put a shortcut in shell:startup
' ============================================================
Set fso = CreateObject("Scripting.FileSystemObject")
strDir = fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))
strPyw = strDir & "\bridge-pythonw.vbs"

' prefer pythonw.exe (windowless) when available
Dim pyw
pyw = "pythonw.exe"
If fso.FileExists("C:\Tools\pythonw.exe") Then pyw = "C:\Tools\pythonw.exe"

Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = strDir
' 0 = hidden window
sh.Run "cmd /c cd /d """ & strDir & """ && " & pyw & " advancebridge.py serve", 0, False
