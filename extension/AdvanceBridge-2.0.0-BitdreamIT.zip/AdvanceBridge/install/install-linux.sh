#!/usr/bin/env bash
# ============================================================
#  AdvanceBridge v2.0.0 - Linux / macOS Installer (Bitdream IT)
#  - ensures CUPS client tools (lp) exist
#  - optionally installs the systemd service (Linux with systemd)
#  Run:  bash install-linux.sh
# ============================================================
set -e
cd "$(dirname "$0")/.."

echo ""
echo " ============================================"
echo "  AdvanceBridge Installer  (Linux / macOS)"
echo "  by Bitdream IT"
echo " ============================================"
echo ""

# ---- 1. Python check ----
if command -v python3 >/dev/null 2>&1; then
    echo " [OK] $(python3 --version) found"
else
    echo " [FAIL] python3 not found."
    echo "        Debian/Ubuntu : sudo apt install python3"
    echo "        RHEL/CentOS   : sudo dnf install python3"
    exit 1
fi

# ---- 2. CUPS client (lp) ----
if command -v lp >/dev/null 2>&1; then
    echo " [OK] CUPS 'lp' found"
else
    echo " [..] Installing cups-client (needs sudo) ..."
    if command -v apt >/dev/null 2>&1; then
        sudo apt update && sudo apt install -y cups-client
    elif command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y cups
    elif command -v yum >/dev/null 2>&1; then
        sudo yum install -y cups
    elif command -v pacman >/dev/null 2>&1; then
        sudo pacman -S --noconfirm cups
    else
        echo " [WARN] Unknown package manager - install 'cups-client' manually."
    fi
fi

# ---- 3. Doctor ----
echo ""
echo " Running doctor check ..."
echo " ------------------------------------------------------------"
python3 advancebridge.py doctor
echo " ------------------------------------------------------------"

# ---- 4. Optional systemd service ----
if [ -d /run/systemd/system ]; then
    echo ""
    printf " Install systemd auto-start service now? [y/N]: "
    read -r ANSWER
    if [ "${ANSWER:-n}" = "y" ]; then
        sudo tee /etc/systemd/system/advancebridge.service > /dev/null <<UNIT
[Unit]
Description=AdvanceBridge silent print bridge (Bitdream IT)
After=network.target cups.service

[Service]
ExecStart=$(command -v python3) $(pwd)/advancebridge.py serve
Restart=always
RestartSec=3
User=$(whoami)
WorkingDirectory=$(pwd)

[Install]
WantedBy=multi-user.target
UNIT
        sudo systemctl daemon-reload
        sudo systemctl enable --now advancebridge
        echo " [OK] service installed and started:"
        systemctl --no-pager status advancebridge | head -5
    else
        echo " Skipped. Start manually with:  python3 advancebridge.py serve"
    fi
else
    echo ""
    echo " (no systemd detected - start manually: python3 advancebridge.py serve)"
fi

echo ""
echo " Installer finished."
