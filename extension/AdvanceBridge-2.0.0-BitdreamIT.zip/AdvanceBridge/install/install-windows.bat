@echo off
REM ============================================================
REM  AdvanceBridge v2.0.0 - Windows Installer  (by Bitdream IT)
REM  What it does:
REM    1. Checks Python is installed
REM    2. Installs SumatraPDF (silent PDF printing engine)
REM    3. Opens firewall port 9234 so office devices can print
REM    4. Runs the doctor check
REM  Double-click this file. If Windows warns, click "More info"
REM  then "Run anyway" (the file is plain text - you can read it).
REM ============================================================
title AdvanceBridge Installer - Bitdream IT
color 0A
echo.
echo  ============================================
echo   AdvanceBridge Installer  (Windows)
echo   by Bitdream IT
echo  ============================================
echo.

REM ---- 1. Python check ----
python --version >nul 2>&1
if errorlevel 1 (
    color 0C
    echo  [FAIL] Python is NOT installed.
    echo.
    echo  1. Open:  https://www.python.org/downloads/windows/
    echo  2. Download Python 3.12
    echo  3. IMPORTANT: tick "Add python.exe to PATH" in the installer
    echo  4. After install, double-click this file again.
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version') do echo  [OK] %%v found

REM ---- 2. SumatraPDF (silent print engine) ----
if exist "%ProgramFiles%\SumatraPDF\SumatraPDF.exe" (
    echo  [OK] SumatraPDF already installed
) else if exist "%ProgramFiles(x86)%\SumatraPDF\SumatraPDF.exe" (
    echo  [OK] SumatraPDF already installed ^(x86^)
) else if exist "%LOCALAPPDATA%\SumatraPDF\SumatraPDF.exe" (
    echo  [OK] SumatraPDF already installed ^(user^)
) else (
    echo  [..] Installing SumatraPDF ...
    winget install -e --id SumatraPDF.SumatraPDF --accept-source-agreements --accept-package-agreements
    if errorlevel 1 (
        echo  [WARN] winget failed. Please install manually:
        echo         https://www.sumatrapdfreader.org/download-free-pdf-viewer
        echo         Then place SumatraPDF.exe in C:\Tools\ if you like.
    )
)

REM ---- 3. Firewall rule (allow office LAN to reach the bridge) ----
net session >nul 2>&1
if errorlevel 1 (
    echo  [WARN] Not running as Administrator - skipping firewall rule.
    echo         If phones/other PCs cannot print, right-click this file
    echo         and choose "Run as administrator", then re-run.
) else (
    netsh advfirewall firewall delete rule name="AdvanceBridge 9234" >nul 2>&1
    netsh advfirewall firewall add rule name="AdvanceBridge 9234" dir=in action=allow protocol=TCP localport=9234 >nul 2>&1
    echo  [OK] Firewall rule added: TCP 9234 open for your LAN
)

REM ---- 4. Doctor check ----
echo.
echo  Running doctor check ...
echo  ------------------------------------------------------------
cd /d "%~dp0.."
python advancebridge.py doctor
echo  ------------------------------------------------------------
echo.
echo  Installer finished.
echo.
echo  NEXT STEPS:
echo    1. Start the bridge:      python advancebridge.py serve
echo    2. Test page:             python advancebridge.py testprint
echo    3. Auto-start at boot:    python advancebridge.py install-service
echo    4. Laravel .env lines:    python advancebridge.py url
echo.
pause
