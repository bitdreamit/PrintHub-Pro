#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================
#  AdvanceBridge v2.0.0  -  Silent Print Bridge for Laravel
#  by Bitdream IT
# ------------------------------------------------------------
#  Web click -> Laravel (mPDF) -> AdvanceBridge -> default printer
#  NO print dialog. NO confirmation. Works from ANY browser.
#
#  * ZERO pip dependencies - pure Python 3.8+ standard library
#  * Cross-platform: Windows (SumatraPDF) / Linux & macOS (CUPS lp)
#  * Office LAN mode: listens on 0.0.0.0, protected by token
#  * A4 PDF invoices + thermal 80mm receipts (auto-built PDF)
#  * Serial print queue (one job at a time = no conflicts)
#  * SQLite print history + reprint from CLI or HTTP
#  * CORS + Private-Network headers: browser JS from any site works
#
#  Quick start:   python advancebridge.py serve
#  Test page:     http://127.0.0.1:9234/health
#  Full check:    python advancebridge.py doctor
#  Help:          python advancebridge.py help
# ============================================================

import base64
import hmac
import json
import os
import queue
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, parse_qsl

VERSION = "2.0.0"
APP_NAME = "AdvanceBridge"
VENDOR = "Bitdream IT"
IS_WIN = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"
HIDE = 0x08000000 if IS_WIN else 0          # no console window flash on Windows
MAX_BODY = 40 * 1024 * 1024                 # 40 MB hard cap on request body
MAX_PDF = 25 * 1024 * 1024                  # 25 MB cap for downloaded pdf_url

# ------------------------------------------------------------
# Configuration (CLI flags / environment variables override)
# ------------------------------------------------------------
CFG = {
    "host": os.environ.get("ADVANCEBRIDGE_HOST", "0.0.0.0"),   # LAN server mode
    "port": int(os.environ.get("ADVANCEBRIDGE_PORT", "9234")),
    "token": os.environ.get("ADVANCEBRIDGE_TOKEN", "BitdreamIT-2024"),
    "printer": os.environ.get("ADVANCEBRIDGE_PRINTER", ""),    # empty = OS default
    "data_dir": os.environ.get(
        "ADVANCEBRIDGE_DATA",
        os.path.join(os.path.expanduser("~"), ".advancebridge"),
    ),
    "keep_files": True,   # keep printed files so /reprint works
}
SUMATRA_HINT = "winget install SumatraPDF.SumatraPDF   (or download from kjkpub.sf.net/sumatrapdf)"

def ensure_dirs():
    os.makedirs(CFG["data_dir"], exist_ok=True)
    os.makedirs(os.path.join(CFG["data_dir"], "jobs"), exist_ok=True)

def db_path():
    return os.path.join(CFG["data_dir"], "history.db")

def log(msg):
    """Console + file log with timestamp."""
    line = "[%s] %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        ensure_dirs()
        with open(os.path.join(CFG["data_dir"], "bridge.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

# ------------------------------------------------------------
# Print history (SQLite) - thread-safe via a single lock
# ------------------------------------------------------------
_DB_LOCK = threading.Lock()

def db():
    conn = sqlite3.connect(db_path(), timeout=10)
    conn.row_factory = sqlite3.Row
    return conn

def db_init():
    ensure_dirs()
    with _DB_LOCK, db() as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS jobs (
                   id         INTEGER PRIMARY KEY AUTOINCREMENT,
                   created_at TEXT NOT NULL,
                   kind       TEXT NOT NULL,            -- a4 | thermal
                   title      TEXT,
                   printer    TEXT,
                   copies     INTEGER DEFAULT 1,
                   status     TEXT NOT NULL,            -- queued|printing|printed|failed
                   error      TEXT,
                   file_path  TEXT,
                   origin_ip  TEXT,
                   duration_ms INTEGER DEFAULT 0
               )"""
        )

def db_add(kind, title, printer, copies, file_path, origin_ip):
    with _DB_LOCK, db() as conn:
        cur = conn.execute(
            "INSERT INTO jobs (created_at, kind, title, printer, copies, status, file_path, origin_ip)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), kind, title, printer,
             copies, "queued", file_path, origin_ip),
        )
        return cur.lastrowid

def db_update(job_id, **fields):
    sets = ", ".join("%s=?" % k for k in fields)
    with _DB_LOCK, db() as conn:
        conn.execute("UPDATE jobs SET %s WHERE id=?" % sets, (*fields.values(), job_id))

def db_get(job_id):
    with _DB_LOCK, db() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(row) if row else None

def db_list(limit=50):
    with _DB_LOCK, db() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs ORDER BY id DESC LIMIT ?", (int(limit),)
        ).fetchall()
        return [dict(r) for r in rows]

# ------------------------------------------------------------
# Printer discovery (best effort, pure stdlib)
# ------------------------------------------------------------
def find_sumatra():
    """Locate SumatraPDF.exe on common Windows paths."""
    if not IS_WIN:
        return None
    cands = [
        r"C:\Tools\SumatraPDF.exe",
        r"C:\Program Files\SumatraPDF\SumatraPDF.exe",
        r"C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\SumatraPDF\SumatraPDF.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\SumatraPDF\SumatraPDF.exe"),
        shutil.which("SumatraPDF.exe"),
    ]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None

def list_printers():
    """Return list of installed printer names (best effort)."""
    try:
        if IS_WIN:
            ps = ("Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=20,
                                 creationflags=HIDE)
            names = [l.strip() for l in (out.stdout or "").splitlines() if l.strip()]
            return names
        else:
            out = subprocess.run(["lpstat", "-e"], capture_output=True,
                                 text=True, timeout=10)
            names = [l.strip() for l in (out.stdout or "").splitlines() if l.strip()]
            if not names:  # older CUPS: try -p and strip state
                out = subprocess.run(["lpstat", "-p"], capture_output=True,
                                     text=True, timeout=10)
                for l in (out.stdout or "").splitlines():
                    if l.startswith("printer "):
                        names.append(l.split()[1])
            return names
    except Exception as e:
        log("[WARN] list_printers failed: %s" % e)
        return []

def default_printer():
    """Return the OS default printer name (best effort)."""
    try:
        if IS_WIN:
            ps = ("(Get-CimInstance Win32_Printer | Where-Object Default)"
                  ".Name")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=20,
                                 creationflags=HIDE)
            name = (out.stdout or "").strip()
            return name or None
        else:
            out = subprocess.run(["lpstat", "-d"], capture_output=True,
                                 text=True, timeout=10)
            for l in (out.stdout or "").splitlines():
                if "system default destination" in l:
                    return l.split(":")[-1].strip()
            return None
    except Exception:
        return None

# ------------------------------------------------------------
# Silent printing back-ends
# ------------------------------------------------------------
def print_file(path, kind="a4", printer="", copies=1):
    """
    Print a PDF file SILENTLY (no dialog) to the given printer
    or the OS default. Raises RuntimeError with a friendly message.
    """
    copies = max(1, min(int(copies or 1), 50))
    target = printer or CFG["printer"] or default_printer() or ""

    if IS_WIN:
        sumatra = find_sumatra()
        if not sumatra:
            raise RuntimeError(
                "SumatraPDF not found. Install it first: %s" % SUMATRA_HINT)
        settings = "noscale" if kind == "thermal" else "shrinkfit"
        if copies > 1:
            settings += ",%dx" % copies
        cmd = [sumatra, "-silent", "-exit-when-done",
               "-print-settings", settings]
        if target:
            cmd += ["-print-to", target]
        cmd.append(path)
        log("[PRINT] SumatraPDF -> %s (%s, %d copy/copies)"
            % (target or "OS default", kind, copies))
        proc = subprocess.run(cmd, capture_output=True, timeout=180,
                              creationflags=HIDE)
        if proc.returncode != 0:
            raise RuntimeError("SumatraPDF exit %d: %s"
                               % (proc.returncode,
                                  (proc.stderr or b"").decode("utf-8", "ignore")[:300]))
    else:
        if shutil.which("lp") is None:
            raise RuntimeError("CUPS 'lp' command not found."
                               " Install cups / cups-client first.")
        cmd = ["lp"]
        if target:
            cmd += ["-d", target]
        if copies > 1:
            cmd += ["-n", str(copies)]
        cmd += ["-o", "fit-to-page" if kind == "a4" else "noscale", path]
        log("[PRINT] lp -> %s (%s, %d copy/copies)"
            % (target or "OS default", kind, copies))
        proc = subprocess.run(cmd, capture_output=True, timeout=180)
        if proc.returncode != 0:
            raise RuntimeError("lp exit %d: %s"
                               % (proc.returncode,
                                  (proc.stderr or b"").decode("utf-8", "ignore")[:300]))
    return target or "OS default"

# ------------------------------------------------------------
# Thermal 80mm receipt: plain text -> minimal PDF (pure Python)
# so it prints silently through the SAME pipeline as invoices.
# ------------------------------------------------------------
def _pdf_escape(s):
    return s.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")

def thermal_pdf_bytes(text, title="receipt", paper="thermal"):
    """
    Build a minimal PDF from plain text (pure Python, no dependencies):
      paper="thermal" -> 80mm receipt roll, Courier 8pt
      paper="a4"      -> 210x297mm page, Courier 11pt
    Markers: #big <line> = large bold heading, |center| <line> = centered.
    Returns (bytes, filename).
    """
    MM = 72 / 25.4
    if paper == "a4":
        W = 210 * MM
        PAGE_H = 297 * MM
        font_pt, lead, max_cols = 11, 5.5 * MM, 95
        big_pt, big_lead = 18, 9 * MM
        top_mm, bottom_pad = 15, 40
    else:
        W = 80 * MM                        # 80mm paper
        PAGE_H = None                      # auto height (receipt roll)
        font_pt, lead, max_cols = 8, 3.6 * MM, 40
        big_pt, big_lead = 13, 6.5 * MM
        top_mm, bottom_pad = 8, 10
    LM = 4 * MM
    lines = []
    for raw in (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if raw.startswith("#big"):
            lines.append(("big", raw[4:].strip()))
        elif raw.startswith("|center|"):
            lines.append(("center", raw[8:].strip()))
        else:
            lines.append(("normal", raw))
    # paginate every N lines
    per_page = 70 if PAGE_H is None else int((PAGE_H - 2 * top_mm * MM) / lead) - 2
    pages, cur = [], []
    for ln in lines:
        cur.append(ln)
        if len(cur) >= per_page:
            pages.append(cur); cur = []
    pages.append(cur or [("normal", "")])

    out = bytearray()
    n = len(pages)
    objs = {}

    def add_obj(idx, body):
        objs[idx] = body

    # fonts: F1 Courier, F2 Courier-Bold
    add_obj(1, b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")
    add_obj(2, b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold >>")

    page_ids = []
    next_id = 3
    content_ids = []
    for pi, page in enumerate(pages):
        H = pages_h(page) if PAGE_H is None else PAGE_H
        stream = []
        y = H - top_mm * MM
        for style, txt in page:
            if style == "big":
                stream.append("BT /F2 %d Tf %d %.1f Td (%s) Tj ET" %
                              (big_pt, int(LM), y, _pdf_escape(txt[:max_cols])))
                y -= big_lead
            else:
                t = txt[:max_cols]
                if style == "center":
                    pad = max(0, (max_cols - len(t)) // 2)
                    t = " " * pad + t
                stream.append("BT /F1 %d Tf %d %.1f Td (%s) Tj ET" %
                              (font_pt, int(LM), y, _pdf_escape(t)))
                y -= lead
        data = ("\n".join(stream)).encode("latin-1", "replace")
        cid = next_id; next_id += 1
        content_ids.append(cid)
        add_obj(cid, b"<< /Length %d >>\nstream\n" % len(data) + data + b"\nendstream")

    pages_id = next_id; next_id += 1
    for pi in range(n):
        pid = next_id; next_id += 1
        page_ids.append(pid)
        H = pages_h(pages[pi]) if PAGE_H is None else PAGE_H
        add_obj(pid,
                ("<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.1f %.1f] "
                 "/Resources << /Font << /F1 1 0 R /F2 2 0 R >> >> "
                 "/Contents %d 0 R >>" % (pages_id, W, H, content_ids[pi])
                 ).encode())
    kids = " ".join("%d 0 R" % p for p in page_ids)
    add_obj(pages_id,
            ("<< /Type /Pages /Kids [%s] /Count %d >>" % (kids, n)).encode())
    cat_id = next_id; next_id += 1
    add_obj(cat_id, ("<< /Type /Catalog /Pages %d 0 R >>" % pages_id).encode())

    # serialize
    out += b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
    offsets = {}
    for idx in sorted(objs):
        offsets[idx] = len(out)
        out += ("%d 0 obj\n" % idx).encode() + objs[idx] + b"\nendobj\n"
    xref = len(out)
    out += ("xref\n0 %d\n" % (next_id)).encode()
    out += b"0000000000 65535 f \n"
    for idx in sorted(objs):
        out += ("%010d 00000 n \n" % offsets[idx]).encode()
    out += ("trailer\n<< /Size %d /Root %d 0 R >>\nstartxref\n%d\n%%%%EOF\n"
            % (next_id, cat_id, xref)).encode()
    fname = "%s-%s.pdf" % (title or "receipt", datetime.now().strftime("%Y%m%d%H%M%S"))
    return bytes(out), "".join(c for c in fname if c.isalnum() or c in "-._")

def pages_h(page_lines):
    MM = 72 / 25.4
    h = 10 * MM + len(page_lines) * 3.6 * MM
    return max(60 * MM, h)

# ------------------------------------------------------------
# Serial print queue: ONE job at a time = no printer conflicts
# ------------------------------------------------------------
jq = queue.Queue()

def worker():
    while True:
        job = jq.get()
        try:
            t0 = time.time()
            db_update(job["id"], status="printing")
            target = print_file(job["file_path"], job["kind"],
                                job["printer"], job["copies"])
            ms = int((time.time() - t0) * 1000)
            db_update(job["id"], status="printed", error=None,
                      duration_ms=ms, printer=target)
            log("[OK] job #%d printed on %s in %d ms"
                % (job["id"], target, ms))
        except Exception as e:
            db_update(job["id"], status="failed", error=str(e)[:500])
            log("[FAIL] job #%d: %s" % (job["id"], e))
        finally:
            # keep the file for reprint (unless it was a temp download)
            if not CFG["keep_files"] and job.get("file_path") \
                    and os.path.exists(job["file_path"]):
                try:
                    os.unlink(job["file_path"])
                except OSError:
                    pass
            jq.task_done()

def start_worker():
    threading.Thread(target=worker, daemon=True, name="print-worker").start()

def save_job_file(kind, title, data):
    """Write payload bytes into the jobs dir; returns full path."""
    ensure_dirs()
    safe = "".join(c for c in (title or "job") if c.isalnum() or c in "-_ ")[:40] or "job"
    fname = "%s-%s-%s.%s" % (safe.replace(" ", "_"),
                             datetime.now().strftime("%Y%m%d%H%M%S"),
                             os.getpid(), "pdf")
    path = os.path.join(CFG["data_dir"], "jobs", fname)
    with open(path, "wb") as f:
        f.write(data)
    return path

def enqueue_print(kind, title, data, printer="", copies=1, origin_ip="-"):
    """Save file + insert DB row + queue it. Returns job id."""
    path = save_job_file(kind, title, data)
    job_id = db_add(kind, title, printer, copies, path, origin_ip)
    jq.put({"id": job_id, "kind": kind, "title": title, "printer": printer,
            "copies": copies, "file_path": path})
    return job_id

# ------------------------------------------------------------
# HTTP API (pure stdlib, CORS-ready for ANY browser/website)
# ------------------------------------------------------------
CORS_HEADERS = [
    ("Access-Control-Allow-Origin", "*"),
    ("Access-Control-Allow-Methods", "GET, POST, OPTIONS"),
    ("Access-Control-Allow-Headers",
     "Content-Type, X-AdvanceBridge-Token, Access-Control-Request-Private-Network"),
    ("Access-Control-Allow-Private-Network", "true"),   # Chrome/Firefox LAN preflight
    ("Access-Control-Max-Age", "86400"),
]

def read_json_body(handler, required=True):
    length = int(handler.headers.get("Content-Length") or 0)
    if length <= 0:
        if required:
            raise ValueError("empty or oversized body (0 bytes)")
        return {}
    if length > MAX_BODY:
        raise ValueError("oversized body (%d bytes)" % length)
    raw = handler.rfile.read(length)
    ctype = (handler.headers.get("Content-Type") or "").lower()
    if "urlencoded" in ctype:
        # Browser hidden-form fallback: field 'payload' carries the JSON.
        fields = dict(parse_qsl(raw.decode("utf-8", "replace")))
        payload = fields.get("payload") or (list(fields.values())[0] if fields else "")
        try:
            return json.loads(payload)
        except Exception:
            raise ValueError("form 'payload' field is not valid JSON")
    return json.loads(raw.decode("utf-8", "replace"))

def download_pdf(url):
    """Fetch a PDF from a URL (used by Laravel 'pdf_url' mode)."""
    req = urllib.request.Request(url, headers={"User-Agent": "AdvanceBridge/%s" % VERSION})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read(MAX_PDF + 1)
    if not data or len(data) > MAX_PDF:
        raise ValueError("pdf_url download too large or empty")
    if not data[:5].startswith(b"%PDF"):
        raise ValueError("pdf_url did not return a PDF")
    return data

class Handler(BaseHTTPRequestHandler):
    server_version = "AdvanceBridge/" + VERSION
    protocol_version = "HTTP/1.1"

    # ---- plumbing ----
    def _cors(self):
        for k, v in CORS_HEADERS:
            self.send_header(k, v)

    def _send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _send_file(self, path, download_name):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            return self._send(404, {"ok": False, "error": "file no longer stored"})
        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition",
                         'attachment; filename="%s"' % download_name)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):     # quieter default logging
        if os.environ.get("ADVANCEBRIDGE_VERBOSE"):
            log("[HTTP] %s %s" % (self.address_string(), fmt % args))

    # ---- auth ----
    def _token_ok(self, qtoken=None, body=None):
        given = (self.headers.get("X-AdvanceBridge-Token")
                 or qtoken
                 or (body or {}).get("token")
                 or "")
        return hmac.compare_digest(str(given), str(CFG["token"]))

    # ---- routes ----
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        qt = (q.get("token") or [""])[0]
        route = u.path.rstrip("/") or "/"

        if route == "/health":                        # open: browser pre-check
            dp = default_printer()
            return self._send(200, {
                "ok": True, "app": APP_NAME, "version": VERSION,
                "os": "windows" if IS_WIN else ("macos" if IS_MAC else "linux"),
                "default_printer": dp,
                "sumatra_found": (find_sumatra() is not None) if IS_WIN else None,
                "queue": jq.qsize(), "token_set": bool(CFG["token"]),
            })

        if not self._token_ok(qt):
            return self._send(401, {"ok": False,
                                    "error": "invalid or missing token"})

        if route == "/":
            return self._send(200, {
                "app": APP_NAME, "version": VERSION, "by": VENDOR,
                "endpoints": ["/health", "/printers", "/jobs", "/jobs/{id}/file",
                              "/jobs/{id}/reprint (POST)", "/print (POST)",
                              "/testprint?kind=a4|thermal"],
            })
        if route == "/printers":
            return self._send(200, {"ok": True,
                                    "printers": list_printers(),
                                    "default": default_printer()})
        if route == "/testprint":
            kind = (q.get("kind") or ["a4"])[0]
            if kind not in ("a4", "thermal"):
                kind = "a4"
            if kind == "thermal":
                data, _ = thermal_pdf_bytes(
                    "#big AdvanceBridge\n|center|Bitdream IT - TEST RECEIPT\n"
                    "--------------------------------\n"
                    "Item 1              10.00\nItem 2              25.50\n"
                    "--------------------------------\n"
                    "TOTAL               35.50\n\n"
                    "|center|Thank you!\n", "testprint")
                title = "test-thermal"
            else:
                data, _ = thermal_pdf_bytes(
                    "#big AdvanceBridge A4 TEST"
                    "\n\nIf this page came out of your printer,"
                    "\nthe bridge is working perfectly."
                    "\n\nTime: %s\n" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "testprint", paper="a4")
                title = "test-a4"
            job = enqueue_print(kind, title, data, origin_ip=self.client_address[0])
            return self._send(200, {"ok": True, "job_id": job, "kind": kind,
                                    "message": "queued - check your printer"})
        if route == "/jobs":
            limit = (q.get("limit") or ["50"])[0]
            return self._send(200, {"ok": True, "jobs": db_list(limit)})
        if route.startswith("/jobs/"):
            parts = route.strip("/").split("/")
            if len(parts) == 3 and parts[2] == "file":
                j = db_get(int(parts[1]) if parts[1].isdigit() else 0)
                if j and j.get("file_path") and os.path.exists(j["file_path"]):
                    return self._send_file(j["file_path"],
                                           "advancebridge-job-%d.pdf" % j["id"])
                return self._send(404, {"ok": False,
                                        "error": "job or file not found"})
        return self._send(404, {"ok": False, "error": "unknown endpoint"})

    def do_POST(self):
        u = urlparse(self.path)
        route = u.path.rstrip("/")
        q = parse_qs(u.query)
        try:
            body = read_json_body(self, required=(route == "/print"))
        except (ValueError, json.JSONDecodeError) as e:
            return self._send(400, {"ok": False, "error": "bad JSON body: %s" % e})

        if not self._token_ok((q.get("token") or [""])[0], body):
            return self._send(401, {"ok": False,
                                    "error": "invalid or missing token"})

        # POST /jobs/{id}/reprint
        if route.startswith("/jobs/") and route.endswith("/reprint"):
            jid = route.strip("/").split("/")[1]
            j = db_get(int(jid) if jid.isdigit() else 0)
            if not j:
                return self._send(404, {"ok": False, "error": "job not found"})
            if not (j.get("file_path") and os.path.exists(j["file_path"])):
                return self._send(410, {"ok": False,
                                        "error": "original file no longer stored"})
            job_id = enqueue_print(j["kind"], (j["title"] or "reprint") + "-reprint",
                                   open(j["file_path"], "rb").read(),
                                   j["printer"] or "", j["copies"] or 1,
                                   self.client_address[0])
            return self._send(200, {"ok": True, "job_id": job_id,
                                    "reprint_of": j["id"]})

        # POST /print
        if route == "/print":
            kind = (body.get("kind") or "").lower()
            title = (body.get("title") or "document")[:60]
            printer = (body.get("printer") or "")[:120]
            copies = body.get("copies") or 1
            try:
                copies = max(1, min(int(copies), 50))
            except (TypeError, ValueError):
                copies = 1

            if body.get("pdf_base64"):
                try:
                    data = base64.b64decode(body["pdf_base64"], validate=False)
                except Exception as e:
                    return self._send(400, {"ok": False,
                                            "error": "bad pdf_base64: %s" % e})
                if not data[:5].startswith(b"%PDF"):
                    return self._send(400, {"ok": False,
                                            "error": "pdf_base64 is not a PDF"})
                kind = kind or "a4"
            elif body.get("pdf_url"):
                try:
                    data = download_pdf(body["pdf_url"])
                except Exception as e:
                    return self._send(400, {"ok": False,
                                            "error": "pdf_url failed: %s" % e})
                kind = kind or "a4"
            elif body.get("text") is not None:
                data, _ = thermal_pdf_bytes(body["text"], title)
                kind = "thermal"
            else:
                return self._send(400, {"ok": False,
                                        "error": "provide pdf_base64, pdf_url or text"})

            if kind not in ("a4", "thermal"):
                kind = "a4"
            job = enqueue_print(kind, title, data, printer, copies,
                                self.client_address[0])
            return self._send(200, {
                "ok": True, "job_id": job, "kind": kind, "copies": copies,
                "message": "queued to printer",
            })

        return self._send(404, {"ok": False, "error": "unknown endpoint"})

# ------------------------------------------------------------
# CLI
# ------------------------------------------------------------
BANNER = r"""
    _                         _ ____
   / \   __ _ ___ _ __   ___ | |  _ \ _   _ ___
  / _ \ / _` / __| '_ \ / _ \| | |_) | | | / __|
 / ___ \ (_| \__ \ |_) | (_) | |  __/| |_| \__ \
/_/   \_\__,_|___/ .__/ \___/|_|_|    \__, |___/
                 |_|                  |___/   v%s  by %s
""" % (VERSION, VENDOR)

ENV_TEMPLATE = """# ---- Add these lines to your Laravel project .env ----
ADVANCEBRIDGE_URL=http://YOUR-PC-LAN-IP:%d      # PC where the printer is attached
ADVANCEBRIDGE_TOKEN=%s
ADVANCEBRIDGE_PRINTER=                          # empty = OS default printer
ADVANCEBRIDGE_TIMEOUT=10
"""

def cmd_serve():
    db_init()
    start_worker()
    addr = (CFG["host"], CFG["port"])
    httpd = ThreadingHTTPServer(addr, Handler)
    httpd.daemon_threads = True
    print(BANNER)
    log("AdvanceBridge v%s listening on http://%s:%d" % (VERSION, CFG["host"], CFG["port"]))
    log("LAN address for Laravel .env -> http://<this-pc-ip>:%d  (token: %s)"
        % (CFG["port"], CFG["token"]))
    log("Local health check          -> http://127.0.0.1:%d/health" % CFG["port"])
    log("Press Ctrl+C to stop.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        log("stopped by user (Ctrl+C)")

def cmd_testprint(kind):
    db_init(); start_worker()
    kind = kind if kind in ("a4", "thermal") else "a4"
    if kind == "thermal":
        data, _ = thermal_pdf_bytes(
            "#big AdvanceBridge\n|center|Bitdream IT - TEST RECEIPT\n"
            "--------------------------------\n"
            "Item 1              10.00\nItem 2              25.50\n"
            "--------------------------------\nTOTAL               35.50\n"
            "\n|center|Thank you!\n", "testprint")
    else:
        data, _ = thermal_pdf_bytes(
            "#big AdvanceBridge TEST PAGE\n\nIf this page printed, the bridge works.\n"
            "Time: %s\n" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "testprint", paper="a4")
    job = enqueue_print(kind, "cli-" + kind, data, origin_ip="cli")
    print("Job #%d queued (%s). Watch the printer..." % (job, kind))

def cmd_history(limit):
    db_init()
    rows = db_list(limit)
    if not rows:
        print("No print jobs yet.")
        return
    print("%-4s %-19s %-8s %-20s %-9s %-7s %s" %
          ("ID", "TIME", "KIND", "PRINTER", "STATUS", "MS", "TITLE"))
    print("-" * 88)
    for r in rows:
        print("%-4s %-19s %-8s %-20s %-9s %-7s %s" %
              (r["id"], (r["created_at"] or "")[0:19], r["kind"],
               (r["printer"] or "-")[:20], r["status"],
               r["duration_ms"] or "-", r["title"] or "-"))

def cmd_reprint(job_id):
    db_init(); start_worker()
    j = db_get(int(job_id))
    if not j:
        print("Job #%s not found." % job_id); sys.exit(1)
    if not (j.get("file_path") and os.path.exists(j["file_path"])):
        print("Original file of job #%s is gone - cannot reprint." % job_id); sys.exit(1)
    with open(j["file_path"], "rb") as f:
        data = f.read()
    nid = enqueue_print(j["kind"], (j["title"] or "reprint") + "-reprint",
                        data, j["printer"] or "", j["copies"] or 1, "cli")
    print("Reprinted as job #%d (copy of #%d)." % (nid, j["id"]))

def cmd_url():
    print(ENV_TEMPLATE % (CFG["port"], CFG["token"]))
    print("# ---- Test from the Laravel server (curl) ----")
    print("""curl -X POST http://YOUR-PC-LAN-IP:%d/print \\
  -H "Content-Type: application/json" \\
  -d '{"token":"%s","pdf_url":"https://example.com/invoice.pdf","title":"Invoice 1"}'"""
          % (CFG["port"], CFG["token"]))

def cmd_doctor():
    print(BANNER)
    results = []
    results.append(("Python >= 3.8", sys.version_info >= (3, 8),
                    sys.version.split()[0]))
    results.append(("OS", True, "windows" if IS_WIN else ("macos" if IS_MAC else "linux")))
    if IS_WIN:
        s = find_sumatra()
        results.append(("SumatraPDF (silent PDF print)", bool(s),
                        s or "NOT FOUND - " + SUMATRA_HINT))
    else:
        lp = shutil.which("lp")
        results.append(("CUPS lp command", bool(lp), lp or "apt install cups-client"))
    try:
        db_init(); results.append(("Data dir + history.db writable", True, CFG["data_dir"]))
    except Exception as e:
        results.append(("Data dir + history.db writable", False, str(e)))
    import socket
    sock = socket.socket()
    try:
        sock.bind(("0.0.0.0", CFG["port"])); free = True
    except OSError:
        free = False
    finally:
        sock.close()
    results.append(("Port %d free" % CFG["port"], free,
                    "OK" if free else "busy - another instance running?"))
    dps = list_printers()
    results.append(("Printers detected", bool(dps),
                    ", ".join(dps[:5]) or "none found (still OK if printing from server PC)"))
    results.append(("Default printer", bool(default_printer()),
                    default_printer() or "none set"))
    ok = True
    for name, passed, info in results:
        print("  [%s] %-34s %s" % ("OK" if passed else "!!", name, info))
        if not passed and "Printers" not in name and "Default printer" not in name:
            ok = False
    print("\n  %s" % ("ALL CHECKS PASSED - you are ready to serve." if ok
                      else "Fix the [!!] items above, then run doctor again."))

LARAVEL_FILES = {
"laravel-generated/.env.additions": """ADVANCEBRIDGE_URL=http://YOUR-PC-LAN-IP:9234
ADVANCEBRIDGE_TOKEN=BitdreamIT-2024
ADVANCEBRIDGE_PRINTER=
ADVANCEBRIDGE_TIMEOUT=10
""",
"laravel-generated/config/advancebridge.php": """<?php
return [
    'url'     => env('ADVANCEBRIDGE_URL', 'http://127.0.0.1:9234'),
    'token'   => env('ADVANCEBRIDGE_TOKEN', 'BitdreamIT-2024'),
    'printer' => env('ADVANCEBRIDGE_PRINTER', ''),
    'timeout' => (int) env('ADVANCEBRIDGE_TIMEOUT', 10),
];
""",
"laravel-generated/app/Services/AdvanceBridgeService.php": '''<?php
namespace App\\Services;

use Illuminate\\Support\\Facades\\Http;

class AdvanceBridgeService
{
    public static function printPdf(string $pdfBinary, array $opt = []): array
    {
        $cfg = config('advancebridge');
        $payload = array_merge([
            'token'      => $cfg['token'],
            'pdf_base64' => base64_encode($pdfBinary),
            'title'      => $opt['title'] ?? 'document',
            'kind'       => $opt['kind'] ?? 'a4',
            'copies'     => $opt['copies'] ?? 1,
        ], $opt['printer'] ? ['printer' => $opt['printer']] : []);

        $res = Http::timeout($cfg['timeout'])
            ->withHeaders(['X-AdvanceBridge-Token' => $cfg['token']])
            ->post(rtrim($cfg['url'], '/') . '/print', $payload);

        if ($res->failed()) {
            throw new \\RuntimeException('AdvanceBridge error: ' . $res->body());
        }
        return $res->json();
    }

    public static function health(): bool
    {
        try {
            return Http::timeout(3)->get(rtrim(config('advancebridge.url'), '/') . '/health')->json('ok') === true;
        } catch (\\Throwable $e) {
            return false;
        }
    }
}
''',
"laravel-generated/routes/web-additions.php": '''<?php
// ---- paste into routes/web.php ----
use App\\Http\\Controllers\\PrintController;

Route::middleware(['auth', 'signed'])
    ->get('/invoice/{invoice}/pdf', [PrintController::class, 'pdf'])
    ->name('invoice.pdf');

Route::middleware('auth')
    ->get('/print/invoice/{invoice}', [PrintController::class, 'printInvoice'])
    ->name('invoice.print');
''',
"laravel-generated/app/Http/Controllers/PrintController.php": '''<?php
namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;

class PrintController extends Controller
{
    // GET /invoice/{id}/pdf  (signed URL) -> raw mPDF stream
    public function pdf(Request $request, $invoice)
    {
        $m = new \\Mpdf\\Mpdf(['mode' => 'utf-8', 'format' => 'A4']);
        $m->WriteHTML(view('invoices.pdf', ['invoice' => $invoice])->render());
        return response($m->Output('', \\Mpdf\\Output\\Destination::STRING_RETURN))
            ->header('Content-Type', 'application/pdf');
    }

    // GET /print/invoice/{id} -> server sends PDF to bridge, prints SILENT
    public function printInvoice(Request $request, $invoice)
    {
        $m = new \\Mpdf\\Mpdf(['mode' => 'utf-8', 'format' => 'A4']);
        $m->WriteHTML(view('invoices.pdf', ['invoice' => $invoice])->render());
        $pdf = $m->Output('', \\Mpdf\\Output\\Destination::STRING_RETURN);

        try {
            \\App\\Services\\AdvanceBridgeService::printPdf($pdf, [
                'title' => 'Invoice-' . ($invoice->id ?? '0'),
            ]);
            return back()->with('print_ok', 'Sent to printer (silent).');
        } catch (\\Throwable $e) {
            return back()->with('print_err', $e->getMessage());
        }
    }
}
''',
"laravel-generated/resources/views/print/auto.blade.php": '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Printing...</title></head>
<body style="font-family:sans-serif;text-align:center;padding-top:60px">
  <h2 id="st">Sending to printer...</h2>
  {!! $pdfBase64 !!}
  <script>
    // Browser fallback: fetch PDF (signed) then POST to local bridge.
    async function go() {
      try {
        const r = await fetch("{{ $pdfUrl }}"); if (!r.ok) throw new Error("PDF " + r.status);
        const b64 = btoa(new Uint8Array(await r.arrayBuffer()).reduce(
          (s, c) => s + String.fromCharCode(c), ""));
        const res = await fetch("http://127.0.0.1:9234/print", {
          method: "POST", headers: {"Content-Type": "application/json",
                                    "X-AdvanceBridge-Token": "{{ $token }}"},
          body: JSON.stringify({pdf_base64: b64, title: {{ Js($title) }}}),
        });
        const j = await res.json();
        document.getElementById("st").textContent =
          j.ok ? "PRINTED - you can close this page" : "FAILED: " + j.error;
      } catch (e) {
        document.getElementById("st").textContent =
          "Bridge not reachable. Is AdvanceBridge running on this PC? (" + e.message + ")";
      }
    }
    go();
  </script>
</body></html>
''',
}

def cmd_laravel():
    for rel, content in LARAVEL_FILES.items():
        path = os.path.join(os.getcwd(), rel)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print("  created: %s" % rel)
    print("\nDone. See laravel-generated/ - then follow laravel/README-LARAVEL.md"
          " inside the project zip.")

def cmd_install_service():
    if IS_WIN:
        pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        if not os.path.exists(pyw):
            pyw = sys.executable
        script = os.path.abspath(__file__)
        schtasks = ('schtasks /Create /F /SC ONSTART /RU SYSTEM /TN AdvanceBridge '
                    '/TR "' + pyw + '" ' + script + ' serve')
        print("Run this ONE command in an Administrator Command Prompt:\n")
        print("  " + schtasks + "\n")
        print("It starts the bridge automatically at every Windows boot (hidden).")
        print("Remove anytime with:  schtasks /Delete /TN AdvanceBridge /F")
    else:
        unit = """[Unit]
Description=AdvanceBridge silent print bridge
After=network.target cups.service

[Service]
ExecStart={python} {script} serve
Restart=always
RestartSec=3
User={user}
WorkingDirectory={cwd}

[Install]
WantedBy=multi-user.target
""".format(python=sys.executable, script=os.path.abspath(__file__),
           user=os.environ.get("USER", "pi"), cwd=os.getcwd())
        print("Save this as /etc/systemd/system/advancebridge.service:\n")
        print(unit)
        print("Then run:\n"
              "  sudo systemctl daemon-reload\n"
              "  sudo systemctl enable --now advancebridge\n"
              "  systemctl status advancebridge")

def cmd_help():
    print(BANNER)
    print("""Commands:
  serve                     Start the bridge (default) - listens on port %d
  testprint [a4|thermal]    Send a test page to the default printer
  printers                  List installed printers
  history [n]               Show last n print jobs (default 20)
  reprint <job_id>          Print a previous job again
  url                       Show Laravel .env lines + curl example
  laravel                   Generate ready-to-paste Laravel files here
  install-service           Auto-start instructions (Windows boot / Linux systemd)
  doctor                    Check everything and report [OK]/[!!]
  help                      This help

Options (environment variables):
  ADVANCEBRIDGE_TOKEN    API token   (default BitdreamIT-2024)
  ADVANCEBRIDGE_PORT     HTTP port   (default 9234)
  ADVANCEBRIDGE_HOST     Bind addr   (default 0.0.0.0 = whole LAN)
  ADVANCEBRIDGE_PRINTER  Force printer name (default: OS default)
  ADVANCEBRIDGE_DATA     Data folder (default ~/.advancebridge)
""" % CFG["port"])

def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "serve"
    try:
        if cmd in ("serve", "start"):
            cmd_serve()
        elif cmd == "testprint":
            cmd_testprint(args[1] if len(args) > 1 else "a4")
        elif cmd == "printers":
            ps = list_printers()
            print("\n".join(ps) or "No printers found.")
        elif cmd == "history":
            cmd_history(int(args[1]) if len(args) > 1 else 20)
        elif cmd == "reprint":
            if len(args) < 2:
                print("usage: python advancebridge.py reprint <job_id>"); sys.exit(1)
            cmd_reprint(args[1])
        elif cmd == "url":
            cmd_url()
        elif cmd == "laravel":
            cmd_laravel()
        elif cmd == "install-service":
            cmd_install_service()
        elif cmd == "doctor":
            cmd_doctor()
        elif cmd in ("help", "--help", "-h"):
            cmd_help()
        elif cmd in ("--version", "version"):
            print("AdvanceBridge v%s by %s" % (VERSION, VENDOR))
        else:
            print("Unknown command: %s\n" % cmd)
            cmd_help(); sys.exit(1)
    except KeyboardInterrupt:
        print("\nBye!")

if __name__ == "__main__":
    main()
