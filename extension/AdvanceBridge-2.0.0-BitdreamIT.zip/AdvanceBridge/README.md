# AdvanceBridge v2.0.0

### Silent Print Bridge for Laravel — by Bitdream IT

**Click a link in any browser → your invoice prints. No dialog. No confirmation. No click on "Print".**

```
 ┌──────────────┐      ┌───────────────────┐      ┌──────────────────────────┐
 │  Any browser │ ---> │  Laravel + mPDF   │ ---> │  AdvanceBridge (Python)  │
 │ Chrome/Edge/ │      │  generates the    │      │  tiny HTTP server with   │
 │ Firefox/Phone│      │  PDF stream       │      │  token auth + queue      │
 └──────────────┘      └───────────────────┘      └───────────┬──────────────┘
                                                              ▼
                                                   ┌─────────────────────┐
                                                   │ OS default printer  │
                                                   │ A4 · thermal 80mm   │
                                                   │ SILENT — zero       │
                                                   │ confirmation        │
                                                   └─────────────────────┘
```

- **Zero dependencies** — pure Python 3.8+ standard library. No pip, no venv.
- **Cross-platform** — Windows (SumatraPDF engine), Linux & macOS (CUPS `lp`).
- **LAN server** — listens on `0.0.0.0:9234`; any device in your office network can trigger printing on the print PC.
- **Token protected** — every request needs `ADVANCEBRIDGE_TOKEN`; constant-time comparison.
- **CORS + Private-Network ready** — browser JavaScript from **any** website (even HTTPS) can talk to the bridge. Includes a hidden-form fallback for strict browsers.
- **A4 + thermal** — PDF invoices and 80mm POS receipts (receipt text is auto-converted to a proper 80mm PDF, still zero dependencies).
- **Print history (SQLite)** — every job is stored and re-printable from CLI or HTTP.
- **Serial queue** — one job at a time; two clicks never fight over the printer.

---

## Contents

```
AdvanceBridge/
├── advancebridge.py        ← the whole tool (one file!)
├── README.md               ← this file
├── QUICKSTART.md           ← 5-minute cheat sheet
├── LICENSE                 ← MIT
├── .env.example            ← bridge-side environment config
├── install/
│   ├── install-windows.bat ← double-click installer (Python + SumatraPDF + firewall)
│   ├── start-windows-hidden.vbs ← start without any window (boot/shortcut)
│   ├── install-linux.sh    ← Linux/macOS installer + optional systemd service
│   └── advancebridge.service ← systemd unit template
├── docs/
│   ├── API.md              ← full HTTP API reference
│   └── ARCHITECTURE.md     ← how the pieces fit (diagrams)
├── laravel/                ← full Laravel integration package
│   ├── README-LARAVEL.md   ← step-by-step Laravel setup
│   ├── .env.additions
│   ├── config/advancebridge.php
│   ├── app/Services/AdvanceBridgeService.php
│   ├── app/Http/Controllers/PrintController.php
│   ├── routes/web-additions.php
│   └── resources/views/print/auto.blade.php   (+ result, + invoice template)
└── examples/
    ├── print-button.html   ← standalone test page (no Laravel needed)
    └── curl-examples.txt
```

---

## Requirements

| | |
|---|---|
| Python | 3.8 or newer — nothing else, no `pip install` |
| Windows | [SumatraPDF](https://www.sumatrapdfreader.org/download-free-pdf-viewer) (the installer `.bat` can install it for you) |
| Linux / macOS | CUPS: `sudo apt install cups-client` (installer does this) |
| Network | Print PC and Laravel server (or browser) must reach each other on port 9234 |

## 1. Install

### Windows (the easy way)

1. Double-click **`install\install-windows.bat`**
   (installs/verifies Python + SumatraPDF, opens firewall port 9234, runs `doctor`).
2. Start it:
   ```
   python advancebridge.py serve
   ```
3. Test: open `http://127.0.0.1:9234/health` in your browser → `{"ok": true, ...}`
4. Test paper: `python advancebridge.py testprint`

### Linux / macOS

```bash
bash install/install-linux.sh          # checks CUPS, offers systemd auto-start
python3 advancebridge.py serve
```

## 2. Configure

All settings are environment variables (see `.env.example`):

| Variable | Default | Meaning |
|----------|---------|---------|
| `ADVANCEBRIDGE_TOKEN` | `BitdreamIT-2024` | Shared secret — **change it in production** |
| `ADVANCEBRIDGE_PORT` | `9234` | HTTP port |
| `ADVANCEBRIDGE_HOST` | `0.0.0.0` | Bind address (`127.0.0.1` = only this PC) |
| `ADVANCEBRIDGE_PRINTER` | *(OS default)* | Force a specific printer name |
| `ADVANCEBRIDGE_DATA` | `~/.advancebridge` | Where history.db + job files live |

Find your LAN IP (`ipconfig` / `hostname -I`) — Laravel needs
`http://<PRINT-PC-IP>:9234` as its bridge URL.

## 3. Connect Laravel

Full step-by-step guide: **[laravel/README-LARAVEL.md](laravel/README-LARAVEL.md)**

```env
ADVANCEBRIDGE_URL=http://192.168.0.50:9234
ADVANCEBRIDGE_TOKEN=BitdreamIT-2024
```

```blade
<a href="{{ route('invoice.print', $invoice) }}">🖨️ Print</a>
```

Click it in Chrome → the invoice prints silently. That's the whole point.

## 4. Daily use (CLI)

```
python advancebridge.py serve              # start the bridge
python advancebridge.py testprint          # test page → default printer
python advancebridge.py testprint thermal  # 80mm receipt test
python advancebridge.py printers           # list installed printers
python advancebridge.py history            # last 20 jobs (status, ms, errors)
python advancebridge.py history 50         # last 50
python advancebridge.py reprint 7          # print job #7 again
python advancebridge.py doctor             # full environment check
python advancebridge.py url                # shows .env lines + curl sample
python advancebridge.py laravel            # writes ready-made Laravel files here
python advancebridge.py install-service    # auto-start at boot
```

## Security notes (read this once)

- The token is the only protection — use a long random value in production and
  keep it out of public repos.
- The bridge binds to your whole LAN by design (office printing). Do **not**
  port-forward 9234 to the internet. If you must, put it behind a reverse
  proxy with TLS (Nginx/Caddy) and keep the token.
- Every job's file is stored under `~/.advancebridge/jobs/` for reprinting.
  Delete old files or the whole folder anytime — the DB row stays for audit.
- Health endpoint (`/health`) is intentionally public so browsers can check
  availability before printing; it exposes no sensitive data.

## Troubleshooting

| Symptom | Cause → Fix |
|---------|-------------|
| `SumatraPDF not found` | Install it, or copy `SumatraPDF.exe` to `C:\Tools\` → run `doctor` again |
| Nothing prints on Windows | Try `python advancebridge.py testprint` and watch `history`; make sure the printer is the OS default |
| Other PCs/phones can't reach the bridge | Firewall → allow TCP 9234 inbound; bridge must run on the PC with the printer |
| HTTP 401 from Laravel | Token mismatch — `.env` value must equal bridge token exactly |
| `Address already in use` | Another bridge instance is running — close it or change `ADVANCEBRIDGE_PORT` |
| Browser page says "Bridge not reachable" | The visitor's PC isn't the print PC → set `ADVANCEBRIDGE_MODE=direct` or `ADVANCEBRIDGE_BROWSER_URL` to the print PC's IP |
| Garbled Bangla/Unicode in thermal receipts | The thermal engine ships with monospace Latin fonts; for Bangla receipts print via the A4/PDF path with an embedded Bangla font (mPDF) |

## License

MIT — see [LICENSE](LICENSE). Built with care by **Bitdream IT**.
